// Run all tests
document.getElementById('btn-run-all').addEventListener('click', async () => {
  const btn = document.getElementById('btn-run-all');
  const summaryEl = document.getElementById('summary');
  const resultsEl = document.getElementById('results');

  btn.disabled = true;
  btn.textContent = '运行中...';
  summaryEl.textContent = '';
  resultsEl.innerHTML = '';

  try {
    const results = await window.etsBridge.runAllTests();
    const passed = results.filter(r => r.passed).length;
    const failed = results.length - passed;

    summaryEl.innerHTML = `<span class="pass">通过: ${passed}</span> | <span class="${failed ? 'fail' : 'pass'}">失败: ${failed}</span> | 总计: ${results.length}`;

    results.forEach(r => {
      const div = document.createElement('div');
      div.className = `test-item ${r.passed ? 'test-pass' : 'test-fail'}`;

      let detail = '';
      if (r.error) {
        detail = `<span class="fail">错误: ${r.error}</span>`;
      } else {
        detail = `期望: ${JSON.stringify(r.expected.value)} | 实际: ${JSON.stringify(r.actual.value)}`;
      }

      div.innerHTML = `<strong>${r.passed ? '✓' : '✗'} ${r.name}</strong><br><small>${detail}</small>`;
      resultsEl.appendChild(div);
    });
  } catch (err) {
    summaryEl.innerHTML = `<span class="fail">测试运行出错: ${err.message}</span>`;
  }

  btn.disabled = false;
  btn.textContent = '运行全部测试';
});

